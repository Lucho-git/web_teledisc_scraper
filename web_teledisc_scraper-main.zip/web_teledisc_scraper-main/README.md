# CryptoRepo
Various Crypto or Exchange related projects

#This codebase is intended to be run from a webserver, I'll use it with heroku

#Telegram scraper, it scrapes messages from telegram and uses them to perform and track trades through the binance exchange
